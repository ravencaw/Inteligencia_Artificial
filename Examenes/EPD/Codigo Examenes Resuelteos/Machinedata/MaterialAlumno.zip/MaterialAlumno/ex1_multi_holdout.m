%  Ejercicio: Linear regression with multiple variables

%% ================ Part 1: Normalizacion de atributos================

%% Clear and Close Figures
clear ; close all; clc

fprintf('Cargando datos ...\n');

%% Load Data 


% Print out some data points

fprintf('Primeras 10 instancias del conjunto de datos: \n');
fprintf(' x = [%.0f %.0f %.0f %.0f %.0f %.0f], y = %.0f \n', [X(1:10,:) y(1:10,:)]');

fprintf('Program paused. Press enter to continue.\n');
pause;

% Scale features and set them to zero mean
fprintf('Normalizando atributos ...\n');


		
% Print out some data points
fprintf('Primeras 10 instancias del conjunto de datos: \n');
fprintf(' x = [%.0f %.0f %.0f %.0f %.0f %.0f], y = %.0f \n', [X(1:10,:) y(1:10,:)]');

fprintf('Program paused. Press enter to continue.\n');
pause;

% Add 1�s to X


%% ================ Part 2: Partici�n para holdout ================



%Elegimos el porcentaje en el que dividimos training/test 
percent = 0.7;


fprintf('Calculando la partici�n training/test por Holdout ...\n');



fprintf('Program paused. Press enter to continue.\n');
pause;

%% ================ Part 3: Descenso del Gradiente ================



fprintf('Ejecutando descenso del gradiente ...\n');

% Choose some alpha value y n�mero de iteraciones


% Init Theta and Run Gradient Descent 



% Plot the convergence graph
figure;
plot(1:numel(J_history), J_history, '-b', 'LineWidth', 2);
xlabel('Number of iterations');
ylabel('Cost J');

% Display gradient descent's result
fprintf('Theta calculado por descenso del gradiente: \n');
fprintf(' %f \n', theta);
fprintf('\n');
  
%% ================ Part 4: Predecir ================  


  


%% ================ Part 5: Evaluar el aprendizaje ================
  

% Calcular el error cometido cuando predices el rendimiento del conjunto de
% ordenadores del conjunto de test X_test



fprintf(['Error (usando descenso del gradiente):\n $%.2f\n'], error);


